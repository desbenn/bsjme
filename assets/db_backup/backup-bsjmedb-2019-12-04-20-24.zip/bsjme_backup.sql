#
# TABLE STRUCTURE FOR: category
#

DROP TABLE IF EXISTS `category`;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active 2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `category` (`id`, `name`, `active`) VALUES (1, 'New member', 1);


#
# TABLE STRUCTURE FOR: city
#

DROP TABLE IF EXISTS `city`;

CREATE TABLE `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(10) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `city` (`id`, `code`, `name`, `active`) VALUES (1, 1, 'Kingston', 1);


#
# TABLE STRUCTURE FOR: client
#

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_register_id` int(11) NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `consultant_id` int(11) DEFAULT NULL,
  `county_id` int(11) NOT NULL,
  `parish_id` int(11) DEFAULT NULL,
  `sector_id` int(11) NOT NULL,
  `step_id` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `board_meeting_time_period` text,
  `business_process` text,
  `client_name` varchar(100) NOT NULL,
  `director_name` varchar(50) DEFAULT NULL,
  `director_register_id` varchar(25) DEFAULT NULL,
  `directory` varchar(100) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `exemption` text,
  `management_review_time` text,
  `mobile` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `postal_box` varchar(45) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `remark` text,
  `website` varchar(100) DEFAULT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_name` (`client_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `client` (`id`, `client_register_id`, `city_id`, `consultant_id`, `county_id`, `parish_id`, `sector_id`, `step_id`, `address`, `board_meeting_time_period`, `business_process`, `client_name`, `director_name`, `director_register_id`, `directory`, `district`, `email`, `exemption`, `management_review_time`, `mobile`, `phone`, `postal_box`, `postal_code`, `remark`, `website`, `active`, `updated_date`, `updated_by`) VALUES (1, 123, 0, 5, 1, 1, 4, 3, '650 Jean-D\'Estrees apt 807', NULL, NULL, 'Client No 1', 'Carmen Gagnon', '', '123', '', 'voyagine@hotmail.com', NULL, NULL, '', '5149836594', ' ', 'H3C0G3', '', '', 1, '2019-09-30 09:28:00', 18);
INSERT INTO `client` (`id`, `client_register_id`, `city_id`, `consultant_id`, `county_id`, `parish_id`, `sector_id`, `step_id`, `address`, `board_meeting_time_period`, `business_process`, `client_name`, `director_name`, `director_register_id`, `directory`, `district`, `email`, `exemption`, `management_review_time`, `mobile`, `phone`, `postal_box`, `postal_code`, `remark`, `website`, `active`, `updated_date`, `updated_by`) VALUES (2, 123456, 0, 3, 1, 1, 1, 1, 'Jamaica', '', '', 'Client No 2', '', '', '123456', '', 'client2@gmail.com', '', '', '', '', '', '', '', '', 1, '2019-10-03 19:08:10', 18);
INSERT INTO `client` (`id`, `client_register_id`, `city_id`, `consultant_id`, `county_id`, `parish_id`, `sector_id`, `step_id`, `address`, `board_meeting_time_period`, `business_process`, `client_name`, `director_name`, `director_register_id`, `directory`, `district`, `email`, `exemption`, `management_review_time`, `mobile`, `phone`, `postal_box`, `postal_code`, `remark`, `website`, `active`, `updated_date`, `updated_by`) VALUES (3, 345, 0, 4, 1, 1, 1, 2, '650 Jean-D\'Estrees apt 807', NULL, NULL, 'Carmen Gagnon Inc', '', '', '345', '', 'voyagine@hotmail.com', NULL, NULL, '', '05149836594', 'H3C0G3', 'H3C0G3', '', '', 1, '2019-12-02 10:20:39', 18);
INSERT INTO `client` (`id`, `client_register_id`, `city_id`, `consultant_id`, `county_id`, `parish_id`, `sector_id`, `step_id`, `address`, `board_meeting_time_period`, `business_process`, `client_name`, `director_name`, `director_register_id`, `directory`, `district`, `email`, `exemption`, `management_review_time`, `mobile`, `phone`, `postal_box`, `postal_code`, `remark`, `website`, `active`, `updated_date`, `updated_by`) VALUES (4, 12345, 0, 3, 1, 0, 2, 1, '650 Jean-D\'Estrees apt 807', NULL, NULL, 'a', '', '', '12345', '', 'voyagine@hotmail.com', NULL, NULL, '', '', 'H3C0G3', 'H3C0G3', '', '', 1, '2019-12-03 12:53:20', 18);
INSERT INTO `client` (`id`, `client_register_id`, `city_id`, `consultant_id`, `county_id`, `parish_id`, `sector_id`, `step_id`, `address`, `board_meeting_time_period`, `business_process`, `client_name`, `director_name`, `director_register_id`, `directory`, `district`, `email`, `exemption`, `management_review_time`, `mobile`, `phone`, `postal_box`, `postal_code`, `remark`, `website`, `active`, `updated_date`, `updated_by`) VALUES (5, 44445555, 0, 3, 1, 1, 4, 2, '650 Jean-D\'Estrees apt 807', 'meetingx', 'processx', 'aaaaaaaaaaaaaa', '', '', '44445555', '', '', 'exemptionx', 'managementx', '', '', 'H3C0G3', 'H3C0G3', 'aaaaaaaaaaaaaaaaaaa', '', 1, '2019-12-04 11:21:56', 18);
INSERT INTO `client` (`id`, `client_register_id`, `city_id`, `consultant_id`, `county_id`, `parish_id`, `sector_id`, `step_id`, `address`, `board_meeting_time_period`, `business_process`, `client_name`, `director_name`, `director_register_id`, `directory`, `district`, `email`, `exemption`, `management_review_time`, `mobile`, `phone`, `postal_box`, `postal_code`, `remark`, `website`, `active`, `updated_date`, `updated_by`) VALUES (6, 2147483647, 1, 3, 1, 1, 4, 1, '650 Jean-D\'Estrees apt 807', 'board meeting time perdiod', 'business process', 'Test after language', 'Director name', 'director register id', '3333444555', 'district', 'voyagine@hotmail.com', 'exemption', 'management review time', 'mobile', 'phone', 'H3C0G3', 'H3C0G3', 'remark', 'website', 1, '2019-12-04 14:53:23', 18);


#
# TABLE STRUCTURE FOR: comment
#

DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: consultant
#

DROP TABLE IF EXISTS `consultant`;

CREATE TABLE `consultant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `remark` text,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `consultant` (`id`, `code`, `name`, `remark`, `active`) VALUES (3, '1', 'Consultant 1', 'Here is the remark about the consultantxxx', 1);
INSERT INTO `consultant` (`id`, `code`, `name`, `remark`, `active`) VALUES (4, '2', 'Consultant 2', NULL, 1);
INSERT INTO `consultant` (`id`, `code`, `name`, `remark`, `active`) VALUES (5, '3', 'Consultant 3', NULL, 1);


#
# TABLE STRUCTURE FOR: county
#

DROP TABLE IF EXISTS `county`;

CREATE TABLE `county` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `county` (`id`, `code`, `name`, `active`) VALUES (1, 0, 'La Union', 1);


#
# TABLE STRUCTURE FOR: document
#

DROP TABLE IF EXISTS `document`;

CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `intervention_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `document_type_id` int(11) DEFAULT NULL,
  `doc_name` varchar(100) DEFAULT NULL,
  `doc_size` int(10) DEFAULT '0',
  `doc_type` varchar(30) DEFAULT NULL,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `intervention_no` (`intervention_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (1, 1, 1, NULL, 2, 'beezzz.png', 40, 'image/png', '2019-09-30 17:24:59', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (2, 1, NULL, NULL, 1, 'logo.jpg', 33, 'image/jpeg', '2019-09-30 17:25:40', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (4, 1, 1, NULL, 5, 'frog.png', 16, 'image/png', '2019-09-30 17:42:51', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (9, 2, NULL, NULL, 1, 'Jamaica.pdf', 570, 'application/pdf', '2019-11-20 11:15:22', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (12, 1, 1, NULL, 2, 'Jamaica.pdf', 570, 'application/pdf', '2019-11-20 11:22:23', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (13, 2, NULL, NULL, 1, 'GAGNONNVTSKU39.pdf', 277, 'application/pdf', '2019-11-22 13:20:43', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (14, NULL, NULL, 5, 6, 'Client_Services_wbs.pdf', 91, 'application/pdf', '2019-11-28 14:18:44', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (15, 3, 2, NULL, 2, 'Jamaica.pdf', 570, 'application/pdf', '2019-12-02 10:40:17', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (16, 3, 2, NULL, 2, 'Client_Servicing_Programme_-_WBS_Dictionary.docx', 18, 'application/vnd.openxmlformats', '2019-12-02 10:49:01', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (17, NULL, NULL, 6, 6, 'Client_Services_wbs1.pdf', 91, 'application/pdf', '2019-12-02 15:38:15', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (18, 3, NULL, NULL, 1, 'Client_Services_Network_Diagram.pdf', 178, 'application/pdf', '2019-12-02 15:59:18', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (19, 3, 3, NULL, 2, 'Client_Services_wbs.pdf', 91, 'application/pdf', '2019-12-03 15:58:46', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (20, 6, 4, NULL, 2, 'List_of_Clients_(2).pdf', 24, 'application/pdf', '2019-12-04 14:54:53', 18);
INSERT INTO `document` (`id`, `client_id`, `intervention_id`, `post_id`, `document_type_id`, `doc_name`, `doc_size`, `doc_type`, `updated_date`, `updated_by`) VALUES (21, 6, NULL, NULL, 1, 'Set_Report_Title.pdf', 24, 'application/pdf', '2019-12-04 14:56:53', 18);


#
# TABLE STRUCTURE FOR: document_type
#

DROP TABLE IF EXISTS `document_type`;

CREATE TABLE `document_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `document_type` (`id`, `name`, `active`) VALUES (1, 'Detail', 1);
INSERT INTO `document_type` (`id`, `name`, `active`) VALUES (2, 'Intervention', 1);
INSERT INTO `document_type` (`id`, `name`, `active`) VALUES (3, 'Association', 1);
INSERT INTO `document_type` (`id`, `name`, `active`) VALUES (4, 'Activities', 1);
INSERT INTO `document_type` (`id`, `name`, `active`) VALUES (5, 'Other', 1);
INSERT INTO `document_type` (`id`, `name`, `active`) VALUES (6, 'Post', 1);


#
# TABLE STRUCTURE FOR: inquiry
#

DROP TABLE IF EXISTS `inquiry`;

CREATE TABLE `inquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `inquiry_type_id` int(11) DEFAULT NULL,
  `support_type_id` int(11) DEFAULT NULL,
  `request` text,
  `feedback` text,
  `answered_by` varchar(50) DEFAULT NULL,
  `inquiry_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `inquiry` (`id`, `client_id`, `inquiry_type_id`, `support_type_id`, `request`, `feedback`, `answered_by`, `inquiry_date`) VALUES (1, 1, 1, 1, 'Voilà le problème', 'Voila la réponse', 'Carmen', '2019-09-16');
INSERT INTO `inquiry` (`id`, `client_id`, `inquiry_type_id`, `support_type_id`, `request`, `feedback`, `answered_by`, `inquiry_date`) VALUES (2, 2, 1, 1, 'sdfdfsfd', '', '', '2019-11-03');
INSERT INTO `inquiry` (`id`, `client_id`, `inquiry_type_id`, `support_type_id`, `request`, `feedback`, `answered_by`, `inquiry_date`) VALUES (3, 3, 1, 1, 'sfsdfsdsadf', 'ggggggggggg', 'cCarneb', '2019-12-02');
INSERT INTO `inquiry` (`id`, `client_id`, `inquiry_type_id`, `support_type_id`, `request`, `feedback`, `answered_by`, `inquiry_date`) VALUES (4, 6, 1, 1, 'rrrx', 'fffx', 'carx', '2019-12-24');


#
# TABLE STRUCTURE FOR: inquiry_type
#

DROP TABLE IF EXISTS `inquiry_type`;

CREATE TABLE `inquiry_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `inquiry_type` (`id`, `code`, `name`, `active`) VALUES (1, 'BEGINNER', 'Beginning the process', 1);


#
# TABLE STRUCTURE FOR: intervention
#

DROP TABLE IF EXISTS `intervention`;

CREATE TABLE `intervention` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `intervention_no` varchar(25) NOT NULL,
  `client_id` int(11) NOT NULL,
  `target_id` int(11) DEFAULT NULL,
  `parish_id` int(11) DEFAULT NULL,
  `phase_id` int(11) NOT NULL,
  `county_id` int(11) DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `area_size` decimal(12,2) DEFAULT NULL,
  `coordinate` varchar(100) DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `date_begin` date DEFAULT NULL,
  `description` varchar(150) DEFAULT NULL,
  `image` text,
  `map` text,
  `remark` text,
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `intervention` (`id`, `intervention_no`, `client_id`, `target_id`, `parish_id`, `phase_id`, `county_id`, `status_id`, `area_size`, `coordinate`, `date_end`, `date_begin`, `description`, `image`, `map`, `remark`, `updated_date`, `updated_by`) VALUES (1, '1', 1, 1, 1, 1, 1, 1, '0.00', '', '2019-09-21', '2019-09-10', 'Get some standards', NULL, '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60706.47797025004!2d-76.83567586028471!3d18.01801477500267!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8edb3f9784ded2a1%3A0x24f321bfabb7af40!2sKingston%2C%20Jamaica!5e0!3m2!1sen!2sca!4v1570381975025!5m2!1sen!2sca\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\"></iframe>                                    ', '<p>Here is a test with company name &lt;?php echo \'companyname\' ?&gt; with the text continuing.</p>', '2019-09-30 09:28:38', 18);
INSERT INTO `intervention` (`id`, `intervention_no`, `client_id`, `target_id`, `parish_id`, `phase_id`, `county_id`, `status_id`, `area_size`, `coordinate`, `date_end`, `date_begin`, `description`, `image`, `map`, `remark`, `updated_date`, `updated_by`) VALUES (2, '345', 3, 2, 1, 1, 1, 1, '0.00', '', '2019-12-14', '2019-12-02', 'Develop a manual', NULL, '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3794.2984630419755!2d-76.79542218483893!3d18.01134718770745!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8edb3fb1fbd40c65%3A0x4f87ee09f0028e91!2sBureau%20of%20Standards%20Jamaica!5e0!3m2!1sfr!2sjm!4v1575320417340!5m2!1sfr!2sjm\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\"></iframe>        ', '', '2019-12-02 10:39:40', 18);
INSERT INTO `intervention` (`id`, `intervention_no`, `client_id`, `target_id`, `parish_id`, `phase_id`, `county_id`, `status_id`, `area_size`, `coordinate`, `date_end`, `date_begin`, `description`, `image`, `map`, `remark`, `updated_date`, `updated_by`) VALUES (3, '1111', 3, 1, 1, 1, 1, 1, NULL, '', '2019-12-27', '2019-12-02', 'test', NULL, '                                    ', '', '2019-12-03 15:57:48', 18);
INSERT INTO `intervention` (`id`, `intervention_no`, `client_id`, `target_id`, `parish_id`, `phase_id`, `county_id`, `status_id`, `area_size`, `coordinate`, `date_end`, `date_begin`, `description`, `image`, `map`, `remark`, `updated_date`, `updated_by`) VALUES (4, 'INT001', 6, 1, 1, 1, 1, 1, '4567.00', '66666', '2019-12-26', '2019-12-02', 'Keep the manual', NULL, '', '<p>testxxx</p>', '2019-12-04 14:54:41', 18);


#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`version`) VALUES ('1');


#
# TABLE STRUCTURE FOR: parish
#

DROP TABLE IF EXISTS `parish`;

CREATE TABLE `parish` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `parish` (`id`, `code`, `name`, `active`) VALUES (1, 0, 'Kingston', 1);
INSERT INTO `parish` (`id`, `code`, `name`, `active`) VALUES (2, 2, 'Westmoreland', 1);


#
# TABLE STRUCTURE FOR: performance
#

DROP TABLE IF EXISTS `performance`;

CREATE TABLE `performance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `standard_number` decimal(12,2) DEFAULT NULL,
  `total_performance` decimal(12,2) DEFAULT NULL,
  `performance_date` date DEFAULT NULL,
  `year` varchar(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `performance` (`id`, `client_id`, `standard_number`, `total_performance`, `performance_date`, `year`) VALUES (1, 1, '5.00', '5000.00', '2019-09-01', '2019');
INSERT INTO `performance` (`id`, `client_id`, `standard_number`, `total_performance`, `performance_date`, `year`) VALUES (2, 1, '111.00', '1000.00', '2019-10-07', '2019');
INSERT INTO `performance` (`id`, `client_id`, `standard_number`, `total_performance`, `performance_date`, `year`) VALUES (3, 3, '4567.00', '5.00', '2019-12-11', '2019');
INSERT INTO `performance` (`id`, `client_id`, `standard_number`, `total_performance`, `performance_date`, `year`) VALUES (4, 6, '111.00', '0.01', '2019-12-03', '2019');


#
# TABLE STRUCTURE FOR: phase
#

DROP TABLE IF EXISTS `phase`;

CREATE TABLE `phase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `phase` (`id`, `name`, `active`) VALUES (1, 'Phase 1', 1);
INSERT INTO `phase` (`id`, `name`, `active`) VALUES (2, 'Phase 2', 1);


#
# TABLE STRUCTURE FOR: post
#

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `doc_type` varchar(30) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_slug` varchar(255) NOT NULL,
  `post_text` text NOT NULL,
  `post_image` varchar(255) NOT NULL,
  `posted_by` varchar(100) NOT NULL,
  `web_visibility` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=visible 2=non visible',
  `active` tinyint(1) NOT NULL COMMENT '1=active 2=inactive',
  `updated_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `post` (`id`, `category_id`, `date_from`, `date_to`, `doc_type`, `post_title`, `post_slug`, `post_text`, `post_image`, `posted_by`, `web_visibility`, `active`, `updated_date`, `updated_by`) VALUES (1, 1, '2019-09-30', '2020-03-28', 'image/jpeg', 'Welcome to new clients!', 'Welcome-to-new-clients', '<p>Welcome to the database for clients.</p>', 'logo.jpg', 'Carmen Gagnon', 1, 1, '2019-09-30 09:39:40', 18);
INSERT INTO `post` (`id`, `category_id`, `date_from`, `date_to`, `doc_type`, `post_title`, `post_slug`, `post_text`, `post_image`, `posted_by`, `web_visibility`, `active`, `updated_date`, `updated_by`) VALUES (4, 1, '2019-11-28', '2020-01-17', 'application/vnd.openxmlformats', 'Message for new members', 'Message-for-new-members', '<p>Here is the message</p>', 'Client_Servicing_Programme_-_WBS_Dictionary.docx', 'Carmen Gagnon', 1, 1, '2019-11-28 14:13:15', 18);
INSERT INTO `post` (`id`, `category_id`, `date_from`, `date_to`, `doc_type`, `post_title`, `post_slug`, `post_text`, `post_image`, `posted_by`, `web_visibility`, `active`, `updated_date`, `updated_by`) VALUES (5, 1, '2019-11-28', '2020-01-17', 'application/pdf', 'Message No 4', 'Message-No-4', '<p>Message no 4 here ius the text</p>', 'Client_Services_Network_Diagram1.pdf', 'Carmen Gagnon', 1, 1, '2019-11-28 14:14:13', 18);
INSERT INTO `post` (`id`, `category_id`, `date_from`, `date_to`, `doc_type`, `post_title`, `post_slug`, `post_text`, `post_image`, `posted_by`, `web_visibility`, `active`, `updated_date`, `updated_by`) VALUES (6, 1, '2019-12-02', '2019-12-27', 'image/gif', 'Visit in BSJ', 'Visit-in-BSJ', '<p>Free zone to write the post.</p>', 'vacance-gif-042.gif', 'Carmen Gagnon', 1, 1, '2019-12-02 15:37:26', 18);


#
# TABLE STRUCTURE FOR: profile
#

DROP TABLE IF EXISTS `profile`;

CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `permission` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO `profile` (`id`, `name`, `permission`) VALUES (1, 'Super Admin', 'a:36:{i:0;s:10:\"createUser\";i:1;s:10:\"updateUser\";i:2;s:8:\"viewUser\";i:3;s:10:\"deleteUser\";i:4;s:11:\"createGroup\";i:5;s:11:\"updateGroup\";i:6;s:9:\"viewGroup\";i:7;s:11:\"deleteGroup\";i:8;s:11:\"createBrand\";i:9;s:11:\"updateBrand\";i:10;s:9:\"viewBrand\";i:11;s:11:\"deleteBrand\";i:12;s:14:\"createCategory\";i:13;s:14:\"updateCategory\";i:14;s:12:\"viewCategory\";i:15;s:14:\"deleteCategory\";i:16;s:11:\"createStore\";i:17;s:11:\"updateStore\";i:18;s:9:\"viewStore\";i:19;s:11:\"deleteStore\";i:20;s:15:\"createAttribute\";i:21;s:15:\"updateAttribute\";i:22;s:13:\"viewAttribute\";i:23;s:15:\"deleteAttribute\";i:24;s:13:\"createProduct\";i:25;s:13:\"updateProduct\";i:26;s:11:\"viewProduct\";i:27;s:13:\"deleteProduct\";i:28;s:11:\"createOrder\";i:29;s:11:\"updateOrder\";i:30;s:9:\"viewOrder\";i:31;s:11:\"deleteOrder\";i:32;s:11:\"viewReports\";i:33;s:13:\"updateCompany\";i:34;s:11:\"viewProfile\";i:35;s:13:\"updateSetting\";}');
INSERT INTO `profile` (`id`, `name`, `permission`) VALUES (8, 'admin', 'a:84:{i:0;s:12:\"createCounty\";i:1;s:12:\"updateCounty\";i:2;s:10:\"viewCounty\";i:3;s:12:\"deleteCounty\";i:4;s:14:\"createCategory\";i:5;s:14:\"updateCategory\";i:6;s:12:\"viewCategory\";i:7;s:14:\"deleteCategory\";i:8;s:10:\"createCity\";i:9;s:10:\"updateCity\";i:10;s:8:\"viewCity\";i:11;s:10:\"deleteCity\";i:12;s:12:\"createClient\";i:13;s:12:\"updateClient\";i:14;s:10:\"viewClient\";i:15;s:12:\"deleteClient\";i:16;s:14:\"createDocument\";i:17;s:14:\"updateDocument\";i:18;s:12:\"viewDocument\";i:19;s:14:\"deleteDocument\";i:20;s:13:\"createInquiry\";i:21;s:13:\"updateInquiry\";i:22;s:11:\"viewInquiry\";i:23;s:13:\"deleteInquiry\";i:24;s:17:\"createInquiryType\";i:25;s:17:\"updateInquiryType\";i:26;s:15:\"viewInquiryType\";i:27;s:17:\"deleteInquiryType\";i:28;s:18:\"createIntervention\";i:29;s:18:\"updateIntervention\";i:30;s:16:\"viewIntervention\";i:31;s:18:\"deleteIntervention\";i:32;s:12:\"createTarget\";i:33;s:12:\"updateTarget\";i:34;s:10:\"viewTarget\";i:35;s:12:\"deleteTarget\";i:36;s:12:\"createSector\";i:37;s:12:\"updateSector\";i:38;s:10:\"viewSector\";i:39;s:12:\"deleteSector\";i:40;s:11:\"createPhase\";i:41;s:11:\"updatePhase\";i:42;s:9:\"viewPhase\";i:43;s:11:\"deletePhase\";i:44;s:10:\"createPost\";i:45;s:10:\"updatePost\";i:46;s:8:\"viewPost\";i:47;s:10:\"deletePost\";i:48;s:13:\"createProfile\";i:49;s:13:\"updateProfile\";i:50;s:11:\"viewProfile\";i:51;s:13:\"deleteProfile\";i:52;s:16:\"createConsultant\";i:53;s:16:\"updateConsultant\";i:54;s:14:\"viewConsultant\";i:55;s:16:\"deleteConsultant\";i:56;s:10:\"createStep\";i:57;s:10:\"updateStep\";i:58;s:8:\"viewStep\";i:59;s:10:\"deleteStep\";i:60;s:12:\"createParish\";i:61;s:12:\"updateParish\";i:62;s:10:\"viewParish\";i:63;s:12:\"deleteParish\";i:64;s:17:\"createSupportType\";i:65;s:17:\"updateSupportType\";i:66;s:15:\"viewSupportType\";i:67;s:17:\"deleteSupportType\";i:68;s:12:\"createStatus\";i:69;s:12:\"updateStatus\";i:70;s:10:\"viewStatus\";i:71;s:12:\"deleteStatus\";i:72;s:17:\"createPerformance\";i:73;s:17:\"updatePerformance\";i:74;s:15:\"viewPerformance\";i:75;s:17:\"deletePerformance\";i:76;s:10:\"createUser\";i:77;s:10:\"updateUser\";i:78;s:8:\"viewUser\";i:79;s:10:\"deleteUser\";i:80;s:10:\"viewReport\";i:81;s:11:\"viewProfile\";i:82;s:13:\"updateSetting\";i:83;s:12:\"updateSystem\";}');
INSERT INTO `profile` (`id`, `name`, `permission`) VALUES (10, 'Reader', 'a:24:{i:0;s:10:\"viewCounty\";i:1;s:12:\"viewCategory\";i:2;s:8:\"viewCity\";i:3;s:10:\"viewClient\";i:4;s:12:\"viewDocument\";i:5;s:11:\"viewInquiry\";i:6;s:15:\"viewInquiryType\";i:7;s:16:\"viewIntervention\";i:8;s:10:\"viewTarget\";i:9;s:10:\"viewSector\";i:10;s:9:\"viewPhase\";i:11;s:8:\"viewPost\";i:12;s:11:\"viewProfile\";i:13;s:14:\"viewConsultant\";i:14;s:8:\"viewStep\";i:15;s:10:\"viewParish\";i:16;s:15:\"viewSupportType\";i:17;s:10:\"viewStatus\";i:18;s:15:\"viewPerformance\";i:19;s:8:\"viewUser\";i:20;s:10:\"viewReport\";i:21;s:13:\"viewReportico\";i:22;s:11:\"viewProfile\";i:23;s:13:\"updateSetting\";}');
INSERT INTO `profile` (`id`, `name`, `permission`) VALUES (11, 'superadmin', 'a:85:{i:0;s:12:\"createCounty\";i:1;s:12:\"updateCounty\";i:2;s:10:\"viewCounty\";i:3;s:12:\"deleteCounty\";i:4;s:14:\"createCategory\";i:5;s:14:\"updateCategory\";i:6;s:12:\"viewCategory\";i:7;s:14:\"deleteCategory\";i:8;s:10:\"createCity\";i:9;s:10:\"updateCity\";i:10;s:8:\"viewCity\";i:11;s:10:\"deleteCity\";i:12;s:12:\"createClient\";i:13;s:12:\"updateClient\";i:14;s:10:\"viewClient\";i:15;s:12:\"deleteClient\";i:16;s:14:\"createDocument\";i:17;s:14:\"updateDocument\";i:18;s:12:\"viewDocument\";i:19;s:14:\"deleteDocument\";i:20;s:13:\"createInquiry\";i:21;s:13:\"updateInquiry\";i:22;s:11:\"viewInquiry\";i:23;s:13:\"deleteInquiry\";i:24;s:17:\"createInquiryType\";i:25;s:17:\"updateInquiryType\";i:26;s:15:\"viewInquiryType\";i:27;s:17:\"deleteInquiryType\";i:28;s:18:\"createIntervention\";i:29;s:18:\"updateIntervention\";i:30;s:16:\"viewIntervention\";i:31;s:18:\"deleteIntervention\";i:32;s:12:\"createTarget\";i:33;s:12:\"updateTarget\";i:34;s:10:\"viewTarget\";i:35;s:12:\"deleteTarget\";i:36;s:12:\"createSector\";i:37;s:12:\"updateSector\";i:38;s:10:\"viewSector\";i:39;s:12:\"deleteSector\";i:40;s:11:\"createPhase\";i:41;s:11:\"updatePhase\";i:42;s:9:\"viewPhase\";i:43;s:11:\"deletePhase\";i:44;s:10:\"createPost\";i:45;s:10:\"updatePost\";i:46;s:8:\"viewPost\";i:47;s:10:\"deletePost\";i:48;s:13:\"createProfile\";i:49;s:13:\"updateProfile\";i:50;s:11:\"viewProfile\";i:51;s:13:\"deleteProfile\";i:52;s:16:\"createConsultant\";i:53;s:16:\"updateConsultant\";i:54;s:14:\"viewConsultant\";i:55;s:16:\"deleteConsultant\";i:56;s:10:\"createStep\";i:57;s:10:\"updateStep\";i:58;s:8:\"viewStep\";i:59;s:10:\"deleteStep\";i:60;s:12:\"createParish\";i:61;s:12:\"updateParish\";i:62;s:10:\"viewParish\";i:63;s:12:\"deleteParish\";i:64;s:17:\"createSupportType\";i:65;s:17:\"updateSupportType\";i:66;s:15:\"viewSupportType\";i:67;s:17:\"deleteSupportType\";i:68;s:12:\"createStatus\";i:69;s:12:\"updateStatus\";i:70;s:10:\"viewStatus\";i:71;s:12:\"deleteStatus\";i:72;s:17:\"createPerformance\";i:73;s:17:\"updatePerformance\";i:74;s:15:\"viewPerformance\";i:75;s:17:\"deletePerformance\";i:76;s:10:\"createUser\";i:77;s:10:\"updateUser\";i:78;s:8:\"viewUser\";i:79;s:10:\"deleteUser\";i:80;s:10:\"viewReport\";i:81;s:13:\"viewReportico\";i:82;s:11:\"viewProfile\";i:83;s:13:\"updateSetting\";i:84;s:12:\"updateSystem\";}');


#
# TABLE STRUCTURE FOR: report
#

DROP TABLE IF EXISTS `report`;

CREATE TABLE `report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_code` char(5) NOT NULL,
  `report_desc` varchar(200) DEFAULT NULL,
  `report_form` varchar(100) NOT NULL,
  `report_title` varchar(100) NOT NULL,
  `report_selection` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1=Yes 2-=No',
  PRIMARY KEY (`id`),
  UNIQUE KEY `report_code` (`report_code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (1, 'REP01', 'List of Clients', '/application/controllers/Repor01.php', 'List of Clients', 1);
INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (2, 'REP02', 'List of Interventions', '/application/controllers/Report02.php', 'List of Interventions', 1);
INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (3, 'REP03', 'Performance', '/application/controllers/Report03.php', 'Performance', 1);
INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (4, 'REP04', 'Inquiries', '/application/controllers/Report04.php', 'Inquiries', 1);
INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (5, 'REP05', 'List of Interventions by County', 'application/controllers/Report05.php', 'List of Interventions by County', 1);
INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (6, 'REP06', 'List of Settings', '/application/controllers/Report06.php', 'List of Settings', 2);
INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (7, 'REP0C', 'Client', '/appliation/controllers/Report0C.php', 'Client', 2);
INSERT INTO `report` (`id`, `report_code`, `report_desc`, `report_form`, `report_title`, `report_selection`) VALUES (8, 'REP0I', 'Intervention', '/appliation/controllers/Report0I.php', 'Intervention', 2);


#
# TABLE STRUCTURE FOR: sector
#

DROP TABLE IF EXISTS `sector`;

CREATE TABLE `sector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `sector` (`id`, `name`, `active`) VALUES (1, 'Industrial', 1);
INSERT INTO `sector` (`id`, `name`, `active`) VALUES (2, 'Agriculture', 1);
INSERT INTO `sector` (`id`, `name`, `active`) VALUES (3, 'Manufacturing', 1);
INSERT INTO `sector` (`id`, `name`, `active`) VALUES (4, 'Exports/Imports', 1);


#
# TABLE STRUCTURE FOR: status
#

DROP TABLE IF EXISTS `status`;

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `status` (`id`, `name`, `active`) VALUES (1, 'Inscription', 1);


#
# TABLE STRUCTURE FOR: step
#

DROP TABLE IF EXISTS `step`;

CREATE TABLE `step` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `step` (`id`, `name`, `active`) VALUES (1, 'Evaluation', 1);
INSERT INTO `step` (`id`, `name`, `active`) VALUES (2, 'Registration', 1);
INSERT INTO `step` (`id`, `name`, `active`) VALUES (3, 'Matriculate', 1);
INSERT INTO `step` (`id`, `name`, `active`) VALUES (4, 'Assessment', 1);
INSERT INTO `step` (`id`, `name`, `active`) VALUES (5, 'Recommendation', 1);
INSERT INTO `step` (`id`, `name`, `active`) VALUES (6, 'Completed', 1);


#
# TABLE STRUCTURE FOR: support_type
#

DROP TABLE IF EXISTS `support_type`;

CREATE TABLE `support_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `support_type` (`id`, `code`, `name`, `active`) VALUES (1, 'RENS', 'Renseignements', 1);


#
# TABLE STRUCTURE FOR: target
#

DROP TABLE IF EXISTS `target`;

CREATE TABLE `target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=active  2=inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `target` (`id`, `code`, `name`, `active`) VALUES (1, '1', 'Target 1', 1);
INSERT INTO `target` (`id`, `code`, `name`, `active`) VALUES (2, '2', 'Target 2', 1);


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `gender` tinyint(1) NOT NULL COMMENT '1=Male  2=Female',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id`, `profile_id`, `username`, `password`, `email`, `name`, `phone`, `gender`) VALUES (18, 11, 'voyagine', '$2y$10$zdSQoIZNy10Gs3uQhG0OF.8xucSKJyP5AEkuCkPY08axj/rNm7lrW', 'voyagine@hotmail.com', 'Carmen Gagnon', '5149836594', 2);
INSERT INTO `user` (`id`, `profile_id`, `username`, `password`, `email`, `name`, `phone`, `gender`) VALUES (20, 10, 'reader', '$2y$10$xvVY2P8uSfgDDqMchI4sEuo9yRpJ2X8ji.pO7Vi5aQIbpl1RLe6IG', 'reader@hotmail.com', 'Mister Reader', '', 1);
INSERT INTO `user` (`id`, `profile_id`, `username`, `password`, `email`, `name`, `phone`, `gender`) VALUES (22, 11, 'french', '$2y$10$MPQFElq5X5pTP0ONGQRcPePRTfrRplotyCheP2p.0xA4Ib9TPSw9S', 'french@hotmail.com', 'French', '', 1);
INSERT INTO `user` (`id`, `profile_id`, `username`, `password`, `email`, `name`, `phone`, `gender`) VALUES (23, 11, 'admin', '$2y$10$R2m6z5viOE1XSz1NXuhateyXjLa.3wsvPAAwys3jG8S3AB4ET3FV6', 'admin@hotmail.com', 'admin', '', 2);
INSERT INTO `user` (`id`, `profile_id`, `username`, `password`, `email`, `name`, `phone`, `gender`) VALUES (24, 8, 'bsjme', '$2y$10$In7QzF0ScvqGZlD.FApJH.W6qHb1urue65e7UfmmAqcJFE7Yp5YR2', 'bsjme@gmail.com', 'bsjme', '', 1);
INSERT INTO `user` (`id`, `profile_id`, `username`, `password`, `email`, `name`, `phone`, `gender`) VALUES (25, 10, '55555555', '$2y$10$Qflh4z8jXHsi7msbH6k/i.lnjLKh0W05BBZPgTgLcnzLh.Rr8T3IG', 'voyaginecg@hotmail.com', 'Carmen Gagnon', '5149836594', 1);


